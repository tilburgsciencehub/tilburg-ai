<?php
/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: My Account
*/

// Check if the user is logged in
if (!is_user_logged_in()) {
    // Redirect to the login page if the user is not logged in
    wp_redirect(wp_login_url());
    exit;
}

// Get the current user
$current_user = wp_get_current_user();

// Include the header and footer templates
get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <header class="entry-header">
            </header>

            <div class="entry-content">
                <div class="container-fluid">
                    <div class="row">
                        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-body-tertiary sidebar collapse">
                            <div class="position-sticky pt-3 sidebar-sticky">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="#">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home align-text-bottom" aria-hidden="true">
                                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                                <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                            </svg>
                                            Dashboard
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file align-text-bottom" aria-hidden="true">
                                                <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                                                <polyline points="13 2 13 9 20 9"></polyline>
                                            </svg>
                                            Favourite Articles
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers align-text-bottom" aria-hidden="true">
                                                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                                                <polyline points="2 17 12 22 22 17"></polyline>
                                                <polyline points="2 12 12 17 22 12"></polyline>
                                            </svg>
                                            Liked Tips
                                        </a>
                                    </li>
                                </ul>

                                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-body-secondary text-uppercase">
                                    <span>Saved reports</span>
                                </h6>

                                <ul class="nav flex-column mb-2">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text align-text-bottom" aria-hidden="true">
                                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                                <polyline points="14 2 14 8 20 8"></polyline>
                                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                                <polyline points="10 9 9 9 8 9"></polyline>
                                            </svg>
                                            User Settings
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </nav>

                        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                                <h1 class="h2">Welcome, <?php echo esc_html($current_user->display_name); ?></h1>
                            </div>
                            <?php
                            $current_user_id = get_current_user_id();
                            $favorites_tips = get_user_meta($current_user_id, 'tilburg_ai_tips_favorites', true);

                            if (!empty($favorites_tips)) {
                                echo '<h2>Your Favorite Tips</h2>';

                                echo '<ul>';
                                foreach ($favorites_tips as $post_id) {
                                    echo '<li><a href="' . esc_url(get_permalink($post_id)) . '">' . get_the_title($post_id) . '</a></li>';
                                }
                                echo '</ul>';
                            } else {
                                echo 'You have no favorite tips.';
                            }
                            ?>
                            <?php
                            $current_user_id = get_current_user_id();
                            $favorites_posts = get_user_meta($current_user_id, 'tilburg_ai_posts_favorites', true);

                            if (!empty($favorites_posts)) {
                                echo '<h2>Your Favorite Blogs</h2>';

                                echo '<ul>';
                                foreach ($favorites_posts as $post_id) {
                                    echo '<li><a href="' . esc_url(get_permalink($post_id)) . '">' . get_the_title($post_id) . '</a></li>';
                                }
                                echo '</ul>';
                            } else {
                                echo 'You have no favorite blogs.';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div><!-- .entry-content -->

        </article><!-- #post-<?php the_ID(); ?> -->

    </main><!-- #main -->
</div><!-- #primary -->

<?php

get_footer();
