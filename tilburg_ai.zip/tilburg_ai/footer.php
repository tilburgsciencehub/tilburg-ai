<!-- Footer Style Settings from Settings Page -->
<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Footer
*/

// Footer Logo
$logo_id = get_option('tilburg-ai-footer-logo');
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : false;

// Colors in Footer
$background_color = get_option('tilburg-ai-footer-background-color');
$text_color = get_option('tilburg-ai-footer-text-color');
$copyright_background_color = get_option('tilburg-ai-footer-copyright-background-color');
$copyright_text_color = get_option('tilburg-ai-footer-copyright-text-color');
?>
<style>
    .footer-content p,
    h4,
    .footer-widget a {
        color: <?php echo $text_color; ?> !important;
    }

    .footer-content-row {
        background-color: <?php 
            if ($background_color){
                echo $background_color; 
            }
            else {
                echo '#ffffff';
            }?>;
    }

    .copyright-text p,
    .copyright-area a{
        color: <?php echo $copyright_text_color; ?> !important;
    }

    .copyright-area {
        background: <?php 
            if ($copyright_background_color){
                echo $copyright_background_color; 
            }
            else {
                echo '#7EA8CE';
            }?> !important;
    }
</style>

<!-- Footer -->
<footer class="footer-section">
    <div class="footer-content-row">
        <div class="container">
            <div class="footer-content pt-5 pb-5">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 mb-50">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="<?php echo esc_url(home_url('/')); ?>">
                                    <?php if ($logo_url) : ?>
                                        <img src="<?php echo esc_url($logo_url); ?>" class="img-fluid" alt="Logo" />
                                    <?php else : ?>
                                        <h1><?php bloginfo('name'); ?></h1>
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="footer-text mt-2">
                                <?php
                                if (get_option('tilburg-ai-footer-text')) {
                                    echo '<p>' . get_option('tilburg-ai-footer-text') . '</>';
                                } else {
                                    echo '<p>Lorem ipsum dolor sit amet, consec tetur adipisicing elit, sed do eiusmod tempor incididuntut consec tetur adipisicing
                                    elit,Lorem ipsum dolor sit amet.</p>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h4>Useful Links</h4>
                            </div>
                            <ul>
                                <?php
                                $footer_menu = get_option('tilburg-ai-footer-menu');
                                $menu_items = wp_get_nav_menu_items($footer_menu);

                                if ($menu_items) {
                                    foreach ($menu_items as $menu_item) {
                                        echo '<li><a href="' . $menu_item->url . '">' . $menu_item->title . '</a></li>';
                                    }
                                }
                                ?>

                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                        <div class="footer-widget">
                            <div class="footer-widget-heading">
                                <h4>Get In Contact</h4>
                            </div>
                            <div class="footer-text mb-25">
                                <div class="email-container">
                                    <i class="fa-solid fa-envelope" style="color:<?php echo $text_color; ?>"></i>
                                    <h6>Email</h6>
                                </div>
                                <p>
                                    <?php
                                    $emailadres = get_option('tilburg-ai-email');

                                    if ($emailadres) {
                                        echo $emailadres;
                                    } else {
                                        echo 'Emailadres';
                                    }
                                    ?>
                                </p>
                                <div class="email-container">
                                    <i class="fa-solid fa-envelope" style="color:<?php echo $text_color; ?>"></i>
                                    <h6>Company Info</h6>
                                </div>
                                <?php
                                if (get_option('tilburg-ai-company-info')) {
                                    echo '<p>' . get_option('tilburg-ai-company-info') . '</>';
                                } else {
                                    echo '<p>Company Info.</p>';
                                }
                                ?>
                            </div>
                            <div class="footer-social-icon">
                                <h6>Follow us</h6>
                                <?php

                                $emailadres = get_option('tilburg-ai-email');
                                $facebook = get_option('tilburg-ai-facebook');
                                $linkedin = get_option('tilburg-ai-linkedin');
                                $instagram = get_option('tilburg-ai-instagram');
                                
                                if ($facebook) {
                                    echo '<a href="' . $facebook . '"><i class="fab fa-facebook-f facebook-bg" style="color:' . $text_color . '"></i></a>';
                                }

                                if ($linkedin) {
                                    echo '<a href="' . $linkedin . '"><i class="fab fa-linkedin linkedin-bg"></i></a>';
                                }

                                if ($instagram) {
                                    echo '<a href="' . $instagram . '"><i class="fab fa-instagram instagram-bg"></i></a>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                    <div class="copyright-text">
                        <?php
                        $copyright_text = get_option('tilburg-ai-footer-copyright-text');

                        if ($copyright_text) {
                            echo '<p>' . $copyright_text . ' © <a href="' . get_bloginfo('url') . '">' . get_bloginfo('name') . '</p>';
                        } else {
                        ?>
                            <p>Copyright &copy; 2023, All Right Reserved <a href="https://tilburgsciencehub.com/">Tilburg Science Hub</a></p>
                        <?php
                        }
                        ?>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                    <div class="footer-menu">
                        <ul>
                            <?php
                            $copyright_menu = get_option('tilburg-ai-footer-copyright-menu');
                            $menu_items = wp_get_nav_menu_items($copyright_menu);

                            if ($menu_items) {
                                foreach ($menu_items as $menu_item) {
                                    echo '<li><a href="' . $menu_item->url . '">' . $menu_item->title . '</a></li>';
                                }
                            } 
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>

<!-- Scripts-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

<!-- Script for dropdown in chatbox-->
<script>
    // get the icon element
    const iconElement = document.querySelector('.position-relative .dropdown i');

    // get all dropdown items
    const dropdownItems = document.querySelectorAll('.dropdown-menu .dropdown-item');

    // loop through dropdown items and add click event listeners
    dropdownItems.forEach(item => {
        item.addEventListener('click', function() {
            // get the icon class from the data-icon attribute
            const iconClass = this.dataset.icon;

            // set the icon class for the icon element
            iconElement.className = iconClass;
        });
    });
</script>

<?php wp_footer(); ?>
</body>

</html>