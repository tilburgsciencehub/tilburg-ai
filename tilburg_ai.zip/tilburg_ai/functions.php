<?php
/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
*/

/**
 * Theme functions and definitions
 */

function enable_custom_menus()
{
    add_theme_support('menus');
}
add_action('after_setup_theme', 'enable_custom_menus');

// Include the theme settings file
function tilburg_ai_include_settings()
{
    require_once get_template_directory() . '/settings/settings.php';
}
add_action('after_setup_theme', 'tilburg_ai_include_settings');

// Support Post Thumbnails
add_theme_support('post-thumbnails');

// Tips Section
function custom_tips_post_type()
{
    $labels = array(
        'name'               => 'Tips',
        'singular_name'      => 'Tip',
        'menu_name'          => 'Tips',
        'name_admin_bar'     => 'Tip',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Tip',
        'new_item'           => 'New Tip',
        'edit_item'          => 'Edit Tip',
        'view_item'          => 'View Tip',
        'all_items'          => 'All Tips',
        'search_items'       => 'Search Tips',
        'parent_item_colon'  => 'Parent Tips:',
        'not_found'          => 'No tips found.',
        'not_found_in_trash' => 'No tips found in Trash.'
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'capability_type'     => 'post',
        'hierarchical'        => false,
        'rewrite'             => array('slug' => 'tips'),
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-lightbulb',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'author', 'comments'),
    );

    register_post_type('tips', $args);
}
add_action('init', 'custom_tips_post_type');

// Add category to tips section
function register_tip_category_taxonomy()
{
    $labels = array(
        'name'                       => _x('Tip Categories', 'taxonomy general name', 'text-domain'),
        'singular_name'              => _x('Tip Category', 'taxonomy singular name', 'text-domain'),
        'search_items'               => __('Search Tip Categories', 'text-domain'),
        'popular_items'              => __('Popular Tip Categories', 'text-domain'),
        'all_items'                  => __('All Tip Categories', 'text-domain'),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __('Edit Tip Category', 'text-domain'),
        'update_item'                => __('Update Tip Category', 'text-domain'),
        'add_new_item'               => __('Add New Tip Category', 'text-domain'),
        'new_item_name'              => __('New Tip Category Name', 'text-domain'),
        'separate_items_with_commas' => __('Separate tip categories with commas', 'text-domain'),
        'add_or_remove_items'        => __('Add or remove tip categories', 'text-domain'),
        'choose_from_most_used'      => __('Choose from the most used tip categories', 'text-domain'),
        'not_found'                  => __('No tip categories found.', 'text-domain'),
        'menu_name'                  => __('Tip Categories', 'text-domain'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'tip-category'),

    );

    register_taxonomy('tip-category', 'tips', $args);
}
add_action('init', 'register_tip_category_taxonomy');

// Change template of Tip Categories
function custom_tip_category_template($template) {
    if (is_tax('tip-category')) {
        $new_template = locate_template(array('tip-category.php'));
        if (!empty($new_template))
            return $new_template;
    }
    return $template;
}
add_filter('template_include', 'custom_tip_category_template', 99);

// Add Codeblock to Tips
function add_codeblock_meta_box()
{
    add_meta_box(
        'codeblock_meta_box',
        'Code Block',
        'render_codeblock_meta_box',
        'tips',
        'normal',
        'high'
    );
}

add_action('add_meta_boxes', 'add_codeblock_meta_box');

// Render Codeblock to Tips
function render_codeblock_meta_box($post)
{
    // Retrieve existing values for codeblock_code and codeblock_shortcode
    $codeblock_code = get_post_meta($post->ID, 'codeblock_code', true);
    $codeblock_shortcode = get_post_meta($post->ID, 'codeblock_shortcode', true);

    // Display the codeblock_code field
    echo '<label for="codeblock_code">Code:</label>';
    echo '<textarea id="codeblock_code" name="codeblock_code" rows="5" style="width:100%;">' . esc_textarea($codeblock_code) . '</textarea>';

    // Display the codeblock_shortcode field
    echo '<label for="codeblock_shortcode">Shortcode:</label>';
    echo '<input type="text" id="codeblock_shortcode" name="codeblock_shortcode" value="' . esc_attr($codeblock_shortcode) . '" />';
}


// Save Settings
function save_codeblock_meta_box($post_id)
{
    // Check if the current user has permission to save the post
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Save the codeblock_code and codeblock_shortcode fields
    if (isset($_POST['codeblock_code'])) {
        update_post_meta($post_id, 'codeblock_code', wp_kses_post($_POST['codeblock_code']));
    }

    if (isset($_POST['codeblock_shortcode'])) {
        update_post_meta($post_id, 'codeblock_shortcode', sanitize_text_field($_POST['codeblock_shortcode']));
    }
}

add_action('save_post_tips', 'save_codeblock_meta_box');

// Retrieve the shortcode from post meta
function get_codeblock_shortcode($post_id)
{
    $shortcode = get_post_meta($post_id, 'codeblock_shortcode', true);
    return $shortcode;
}

// Add Shortcode
function codeblock_shortcode($atts, $content = null)
{
    // Retrieve the shortcode value from the post meta
    $post_id = get_the_ID();
    $shortcode = get_codeblock_shortcode($post_id);

    // Retrieve the codeblock_code value from the post meta
    $codeblock_code = get_post_meta($post_id, 'codeblock_code', true);

    // Output the code block
    ob_start();
?>
    <pre><code><?php echo esc_html($codeblock_code); ?></code></pre>
<?php
    return ob_get_clean();
}

// Register the shortcode dynamically
function register_dynamic_shortcode()
{
    global $post;

    // Check if we have a valid post object
    if ($post instanceof WP_Post) {
        $shortcode = get_codeblock_shortcode($post->ID);

        if (!empty($shortcode)) {
            add_shortcode($shortcode, 'codeblock_shortcode');
        } else {
            add_shortcode('testblock', 'codeblock_shortcode');
        }
    }
}

// Hook the function to appropriate actions
add_action('wp', 'register_dynamic_shortcode');
add_action('admin_init', 'register_dynamic_shortcode');

// Enqueue scripts
function enqueue_jquery()
{
    wp_enqueue_script('jquery');
    wp_localize_script('custom-script', 'customAjax', array('ajaxurl' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_jquery');

function tilburg_ai_enqueue_scripts()
{
    wp_enqueue_media();
    wp_enqueue_script('tilburg-ai-admin', get_template_directory_uri() . '/js/admin.js', array('jquery'), '1.0', true);
}

add_action('admin_enqueue_scripts', 'tilburg_ai_enqueue_scripts');

// Customize the login page design
function my_custom_login_logo()
{
    $logo = get_option('tilburg-ai-logo');
    $image_url = wp_get_attachment_url($logo);
?>
    <style type="text/css">
        .login h1 a {
            background-image: url('<?php echo esc_url($image_url); ?>') !important;
            background-size: contain;
            width: 100%;
            height: 100px;
        }

        .login form {
            border-radius: 10px;
        }

        body {
            <?php
            $login_color = get_option('tilburg-ai-login-color');
            $background_color = null !== $login_color ? $login_color : '#D9E6F6';
            echo 'background-color: ' . esc_attr($background_color) . ' !important;';
            ?>
        }
    </style>
<?php
}
add_action('login_enqueue_scripts', 'my_custom_login_logo');

// Change the logo URL and title on the login page
function my_login_logo_url()
{
    return home_url();
}
add_filter('login_headerurl', 'my_login_logo_url');

function my_login_logo_url_title()
{
    return 'Tilburg AI';
}
add_filter('login_headertitle', 'my_login_logo_url_title');

// Callback function to add a "Tips" post to favorites

function add_to_favorites()
{
    $post_id = $_POST['post_id'];
    $user_id = get_current_user_id();

    // Check if the post is already favorited by the user
    $favorites = get_user_meta($user_id, 'tilburg_ai_tips_favorites', true);
    $favorites = maybe_unserialize($favorites);
    $favorites = is_array($favorites) ? $favorites : array(); // Ensure $favorites is an array

    if (in_array($post_id, $favorites)) {
        // Post is already favorited, so remove it from favorites
        $favorites = array_diff($favorites, array($post_id));
        update_user_meta($user_id, 'tilburg_ai_tips_favorites', $favorites);

        wp_send_json_success(array('message' => 'removed'));
    } else {
        // Post is not favorited, so add it to favorites
        $favorites[] = $post_id;
        update_user_meta($user_id, 'tilburg_ai_tips_favorites', $favorites);

        wp_send_json_success(array('message' => 'added'));
    }
}

add_action('wp_ajax_add_to_favorites_tips', 'add_to_favorites');
add_action('wp_ajax_nopriv_add_to_favorites_tips', 'add_to_favorites');

function add_to_favorites_posts()
{
    $post_id = $_POST['post_id'];
    $user_id = get_current_user_id();

    // Check if the post is already favorited by the user
    $favorites = get_user_meta($user_id, 'tilburg_ai_posts_favorites', true);
    $favorites = maybe_unserialize($favorites);
    $favorites = is_array($favorites) ? $favorites : array(); // Ensure $favorites is an array

    if (in_array($post_id, $favorites)) {
        // Post is already favorited, so remove it from favorites
        $favorites = array_diff($favorites, array($post_id));
        update_user_meta($user_id, 'tilburg_ai_posts_favorites', $favorites);

        wp_send_json_success(array('message' => 'removed'));
    } else {
        // Post is not favorited, so add it to favorites
        $favorites[] = $post_id;
        update_user_meta($user_id, 'tilburg_ai_posts_favorites', $favorites);

        wp_send_json_success(array('message' => 'added'));
    }
}

add_action('wp_ajax_add_to_favorites_posts', 'add_to_favorites_posts');
add_action('wp_ajax_nopriv_add_to_favorites_posts', 'add_to_favorites_posts');


// Add image to categories
function add_category_image_field()
{
    // Register the "category-image" taxonomy for the "category" taxonomy
    register_taxonomy_for_object_type('category-image', 'category');

    // Add the "category-image" field to the "category" taxonomy edit screen
    add_action('category_add_form_fields', 'add_category_image_field_markup');
    add_action('category_edit_form_fields', 'add_category_image_field_markup');

    // Save the "category-image" field data
    add_action('created_category', 'save_category_image_field');
    add_action('edited_category', 'save_category_image_field');
}
add_action('init', 'add_category_image_field');

function add_category_image_field_markup($term)
{
    $category_image_id = get_term_meta($term->term_id, 'category_image', true);
    $category_image_url = wp_get_attachment_image_url($category_image_id, 'thumbnail');

?>
    <div class="form-field">
        <label for="category_image"><?php esc_html_e('Category Image', 'text-domain'); ?></label>
        <input type="hidden" id="category_image" name="category_image" value="<?php echo esc_attr($category_image_id); ?>">
        <img src="<?php echo esc_url($category_image_url); ?>" alt="<?php esc_attr_e('Category Image', 'text-domain'); ?>" style="max-width: 100px; height: auto;">
        <p>
            <input type="button" class="button button-secondary" id="category_image_button" value="<?php esc_attr_e('Select Image', 'text-domain'); ?>">
            <input type="button" class="button button-secondary" id="category_image_remove_button" value="<?php esc_attr_e('Remove Image', 'text-domain'); ?>">
        </p>
    </div>
<?php
}

function save_category_image_field($term_id)
{
    if (isset($_POST['category_image'])) {
        $category_image_id = absint($_POST['category_image']);
        update_term_meta($term_id, 'category_image', $category_image_id);
    }
}

function enqueue_category_image_scripts()
{
    if (is_admin()) {
        wp_enqueue_script('category-image', get_stylesheet_directory_uri() . '/js/category-image.js', array('jquery', 'media-upload', 'thickbox'));
        wp_enqueue_style('thickbox');
    }
}
add_action('admin_enqueue_scripts', 'enqueue_category_image_scripts');

// THEME ACTIVATION FUNCTIONS (DEMO DATA & PAGES)

// Create Categories Page on theme activation
function create_categories_page()
{
    // Check if the Categories page exists
    $categories_page = get_page_by_title('Categories');

    // Create the Categories page if it doesn't exist
    if (!$categories_page) {
        $page_id = wp_insert_post(array(
            'post_title'     => 'Categories',
            'post_content'   => '',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ));

        if ($page_id) {
            // Assign the Categories Page template
            update_post_meta($page_id, '_wp_page_template', 'categories_template.php');
        }
    }
}

// Hook the function to theme activation
add_action('after_setup_theme', 'create_categories_page');

// Create My Account Page on theme activation
function create_my_account_page()
{
    // Check if the My Account page exists
    $my_account_page = get_page_by_title('My Account');

    // Create the My Account page if it doesn't exist
    if (!$my_account_page) {
        $page_id = wp_insert_post(array(
            'post_title'     => 'My Account',
            'post_content'   => '',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ));

        if ($page_id) {
            // Assign the My Account Page template
            update_post_meta($page_id, '_wp_page_template', 'my-account.php');
        }
    }
}

// Hook the function to theme activation
add_action('after_setup_theme', 'create_my_account_page');

// Create Tip Categories on theme activation
function create_tip_categories_page()
{
    // Check if the My Account page exists
    $tip_categories_page = get_page_by_title('Tip Categories');

    // Create the My Account page if it doesn't exist
    if (!$tip_categories_page) {
        $page_id = wp_insert_post(array(
            'post_title'     => 'Tip Categories',
            'post_content'   => '',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
            'post_name'      => 'tip-categories',
        ));        

        if ($page_id) {
            // Assign the My Account Page template
            update_post_meta($page_id, '_wp_page_template', 'tip-categories.php');
        }
    }
}

// Hook the function to theme activation
add_action('after_setup_theme', 'create_tip_categories_page');

// Add Default Tip Category
function create_default_tip_category()
{
    $category_name = 'Top Tips';
    $category_slug = 'top-tips';

    $existing_category = get_term_by('slug', $category_slug, 'tip-category');

    if ($existing_category === false) {
        $category = wp_insert_term($category_name, 'tip-category', array(
            'slug' => $category_slug,
        ));

        // Update the option 'tilburg-ai-tip-category' with the newly created category ID
        if (!is_wp_error($category) && isset($category['term_id'])) {
            $tip_category = $category['term_id'];
            update_option('tilburg-ai-tip-category', $tip_category);
        }
    }
}
add_action('after_switch_theme', 'create_default_tip_category');

// Add Default Post Category
function add_default_post_category()
{
    $category_name = 'Top Articles';
    $category_slug = 'top-articles';

    // Check if the category already exists
    $category_exists = term_exists($category_name, 'category');

    if (!$category_exists) {
        // Create the category
        $category_args = array(
            'slug' => $category_slug,
        );
        $category = wp_insert_term($category_name, 'category', $category_args);

        // Update the option 'tilburg-ai-top-category' with the newly created category ID
        if (!is_wp_error($category) && isset($category['term_id'])) {
            $top_category = $category['term_id'];
            update_option('tilburg-ai-top-category', $top_category);
        }
    }
}
add_action('after_switch_theme', 'add_default_post_category');

// Add Default Tips
function add_default_tips()
{

    $tip_count = wp_count_posts('tips')->publish;

    if ($tip_count == 0) {

        $tips = array(
            array(
                'title' => 'Lorem Ipsum Tip 1',
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ),
            array(
                'title' => 'Lorem Ipsum Tip 2',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
            array(
                'title' => 'Lorem Ipsum Tip 3',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
            array(
                'title' => 'Lorem Ipsum Tip 4',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
            array(
                'title' => 'Lorem Ipsum Tip 5',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
            array(
                'title' => 'Lorem Ipsum Tip 6',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ),
        );

        // Get the term ID of the "top-tips" category
        $term = get_term_by('slug', 'top-tips', 'tip-category');
        $category_id = $term->term_id;

        foreach ($tips as $tip) {
            $post_data = array(
                'post_title' => $tip['title'],
                'post_content' => $tip['content'],
                'post_type' => 'tips',
                'post_status' => 'publish',
            );

            // Insert the tip post
            $post_id = wp_insert_post($post_data);

            // Assign the post to the "top-tips" category
            wp_set_post_terms($post_id, array($category_id), 'tip-category');
        }
    }
}

add_action('after_switch_theme', 'add_default_tips');

// Add Default Posts
function add_default_posts()
{
    $post_count = wp_count_posts('post')->publish;

    if ($post_count == 0) {
        $posts = array(
            array(
                'title' => 'Lorem Ipsum Post 1',
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 2',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 3',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 4',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 5',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 6',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'top-articles',
            ),
            array(
                'title' => 'Lorem Ipsum Post 7',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 8',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 9',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 10',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 11',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 12',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 13',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 14',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
            array(
                'title' => 'Lorem Ipsum Post 15',
                'content' => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'category' => 'uncategorized',
            ),
        );

        foreach ($posts as $post) {
            $post_data = array(
                'post_title'   => $post['title'],
                'post_content' => $post['content'],
                'post_type'    => 'post',
                'post_status'  => 'publish',
            );

            // Insert the post
            $post_id = wp_insert_post($post_data);

            // Get the category ID by slug
            $category_id = get_category_by_slug($post['category'])->term_id;

            // Assign the post to the category
            wp_set_post_categories($post_id, array($category_id));
        }
    }
}
add_action('after_switch_theme', 'add_default_posts');

function create_default_menu() {
    // Check if any menus exist
    $menus = get_terms('nav_menu');
    
    // If no menus exist, create a new menu
    if (empty($menus)) {
        $menu_name = 'Default Menu';
        $menu_slug = 'default-menu';
        
        // Create the menu
        $menu_id = wp_create_nav_menu($menu_name);
        
        // Set the menu location
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
        
        // Add menu items
        $menu_items = array(
            array(
                'title' => 'Categories',
                'slug' => 'categories',
            ),
            array(
                'title' => 'Privacy Policy',
                'slug' => 'privacy-policy',
            ),
            array(
                'title' => 'Sample Page',
                'slug' => 'sample-page',
            ),
        );
        
        foreach ($menu_items as $item) {
            // Get the page ID based on the slug
            $page = get_page_by_path($item['slug']);
            
            // Create a menu item if the page exists
            if ($page) {
                $item_data = array(
                    'menu-item-title' => $item['title'],
                    'menu-item-object-id' => $page->ID,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status' => 'publish',
                );
                
                wp_update_nav_menu_item($menu_id, 0, $item_data);
            }
        }
        update_option('tilburg-ai-header-menu', $menu_id);
        update_option('tilburg-ai-footer-menu', $menu_id);
        update_option('tilburg-ai-footer-copyright-menu', $menu_id);
    }
}
add_action('after_switch_theme', 'create_default_menu');

// Set the default value for "tilburg-ai-enable-likes"
function set_default_enable_likes_option() {
    $default_value = 'false';
    $current_value = get_option('tilburg-ai-enable-likes', '');

    if ($current_value === '') {
        update_option('tilburg-ai-enable-likes', $default_value);
    }
}
add_action('after_switch_theme', 'set_default_enable_likes_option');

// Set the default value for "tilburg-ai-enable-likes"
function set_default_enable_favourites_option() {
    $default_value = 'false';
    $current_value = get_option('tilburg-ai-enable-favourites', '');

    if ($current_value === '') {
        update_option('tilburg-ai-enable-favourites', $default_value);
    }
}
add_action('after_switch_theme', 'set_default_enable_favourites_option');


// Set default value for header
function set_default_banner_option() {
    $default_value = 'header';
    $current_value = get_option('tilburg-ai-tip-category-display', '');

    if ($current_value === '') {
        update_option('tilburg-ai-tip-category-display', $default_value);
    }
}
add_action('after_switch_theme', 'set_default_banner_option');

// Set default value for most read post
function set_default_most_read_option() {
    $default_slug = 'lorem-ipsum-post-7';
    $default_post = get_page_by_path($default_slug, OBJECT, 'post');

    if ($default_post) {
        $default_value = $default_post->ID;
        $current_value = get_option('tilburg-ai-most-read-post', '');

        if ($current_value === '') {
            update_option('tilburg-ai-most-read-post', $default_value);
        }
    }
}
add_action('after_switch_theme', 'set_default_most_read_option');


?>