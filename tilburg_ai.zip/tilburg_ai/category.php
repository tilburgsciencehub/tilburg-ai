<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Post Category Page
*/

get_header();
?>
<div class="category_page_banner">
    <h1 class="category_title mb-4" style="color:white !important;"><?php single_cat_title(); ?></h1>
    <div class="search-form-container">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" class="search-field" placeholder="<?php echo esc_attr__('Search your article', 'textdomain'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
            <i class="fa fa-search search-box-icon"></i>
        </form>
    </div>
</div>

<!-- Categories Overlap -->
<div class="category_page_categories_overlap">
    <div class="container">
        <div class="row">
            <div class="col-lg-10">
                <div class="row justify-content-between">
                    <?php
                    $categories = get_categories();
                    $current_category_id = get_queried_object_id();

                    foreach ($categories as $category) {
                        if ($category->term_id === $current_category_id) {
                            continue; // Skip the current category
                        }

                        $category_image_id = get_term_meta($category->term_id, 'category_image', true);
                        $category_image_url = wp_get_attachment_image_url($category_image_id, 'thumbnail');
                    ?>

                        <div class="category_page_col">
                            <a href="<?php echo get_category_link($category->term_id); ?>">
                                <?php if ($category_image_url) { ?>
                                    <img src="<?php echo esc_url($category_image_url); ?>" alt="<?php echo esc_attr__('Category Image', 'text-domain'); ?>">
                                <?php } else { ?>
                                    <img src="https://picsum.photos/150/150">
                                <?php } ?>
                                <h5><?php echo $category->name; ?></h5>
                            </a>
                        </div>

                    <?php
                    }
                    ?>

                </div>
            </div>

            <div class="col-lg-2 d-flex align-self-center justify-content-center">
                <a href="<?php echo home_url('/categories'); ?>">
                    <div class="category_page_col_more align-self-center justify-content-center">
                        <i class="fa-solid fa-right-long fa-xl mb-3"></i>
                        <h5>More</h5>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>

<div class="category-page">
    <div class="container py-5">
        <h3 style="text-align: center;color:white !important">Articles in this category</h3>
        <hr>
        <?
        if (have_posts()) {
            $x = 0;
        ?>
            <div class="row">
                <?php
                while (have_posts()) {

                    the_post();
                    // Display the post content or any other desired information
                ?>
                    <div class="col-lg-3 p-3">

                        <div class="category_page_article">
                            <?php
                            the_title('<h3>', '</h3>'); ?>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a class="btn btn-secondary" href="<?php the_permalink(); ?>">Read More</a>
                        </div>
                    </div>
            <?php
                    $x = $x + 1;
                }
            } else {
                echo 'No posts found.';
            }
            ?>
            </div>
    </div>
    <?php
    get_footer();
