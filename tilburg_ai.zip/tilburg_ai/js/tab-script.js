jQuery(document).ready(function($) {
    // Hide all tab sections except the first one
    $('.tilburg-ai-settings-tab-section:not(:first)').hide();

    // Handle tab clicks
    $('.tilburg-ai-settings-tab-links a').click(function(e) {
        e.preventDefault();

        // Get the target tab's ID
        var target = $(this).attr('href');

        // Hide all tab sections
        $('.tilburg-ai-settings-tab-section').hide();

        // Show the target tab section
        $(target).show();

        // Update the active tab link
        $('.tilburg-ai-settings-tab-links a').removeClass('active');
        $(this).addClass('active');
    });
});