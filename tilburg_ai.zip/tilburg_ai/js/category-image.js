jQuery(document).ready(function($) {
    var customUploader;

    $('#category_image_button').click(function(e) {
        e.preventDefault();

        if (customUploader) {
            customUploader.open();
            return;
        }

        customUploader = wp.media.frames.file_frame = wp.media({
            title: 'Select Category Image',
            button: {
                text: 'Select Image'
            },
            multiple: false
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').first().toJSON();
            $('#category_image').val(attachment.id);
            $('#category_image').siblings('img').attr('src', attachment.url);
        });

        customUploader.open();
    });

    $('#category_image_remove_button').click(function(e) {
        e.preventDefault();

        $('#category_image').val('');
        $('#category_image').siblings('img').attr('src', '');
    });
});