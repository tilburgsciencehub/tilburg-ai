jQuery(document).ready(function($) {
    var logoUploader;

    $('#tilburg-ai-logo-upload-button').on('click', function(e) {
        e.preventDefault();

        if (logoUploader) {
            logoUploader.open();
            return;
        }

        logoUploader = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Select'
            },
            multiple: false
        });

        logoUploader.on('select', function() {
            var attachment = logoUploader.state().get('selection').first().toJSON();
            $('#tilburg-ai-logo').val(attachment.id);
            $('#tilburg-ai-logo-preview').html('<img src="' + attachment.url + '" alt="Logo" width="150" />');
        });

        logoUploader.open();
    });

    $('#tilburg-ai-logo-remove-button').on('click', function(e) {
        e.preventDefault();
        $('#tilburg-ai-logo').val('');
        $('#tilburg-ai-logo-preview').html('');
    });
});
