
        // get the icon element
        const iconElement = document.querySelector('.position-relative .dropdown i');

        // get all dropdown items
        const dropdownItems = document.querySelectorAll('.dropdown-menu .dropdown-item');

        // loop through dropdown items and add click event listeners
        dropdownItems.forEach(item => {
            item.addEventListener('click', function () {
                // get the icon class from the data-icon attribute
                const iconClass = this.dataset.icon;

                // set the icon class for the icon element
                iconElement.className = iconClass;
            });
        });

        import Swiper from 'https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.esm.browser.min.js'
        const swiper = new Swiper('.swiper', {
            // Optional parameters
            direction: 'horizontal',
            loop: true,

            // Navigation arrows
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },

            slidesPerView: 5,
            spaceBetween: 20,

            breakpoints: {
                // when window width is >= 320px
                320: {
                    slidesPerView: 2,
                    spaceBetween: 20
                },
                // when window width is >= 480px
                480: {
                    slidesPerView: 3,
                    spaceBetween: 20
                },
                // when window width is >= 640px
                640: {
                    slidesPerView: 5,
                    spaceBetween: 32
                }
            }
        });
        
        var windowHeight = window.innerHeight;

        var myElement = document.getElementById('my-element');

        var nestedDivs = myElement.querySelectorAll('#infinity_scroll_item_row');

        nestedDivs[0].style.display = 'flex'

        $(window).scroll(function () {
            for (var i = 0; i < nestedDivs.length; i++) {

                if (nestedDivs[i].style.display === 'flex' && nestedDivs[i].getBoundingClientRect().top < windowHeight) {
                    var nextDiv = i + 1
                    nestedDivs[nextDiv].style.display = 'flex'
                } else {
                    console.log('Element is not within the visible portion of the window');
                }
            }
        })