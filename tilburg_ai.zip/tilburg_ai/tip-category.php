<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Tip Category
*/

get_header();
?>
<div class="category_page_banner">
    <h1 class="category_title mb-4" style="color:white !important;"><?php single_cat_title(); ?></h1>
    <div class="search-form-container">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" class="search-field" placeholder="<?php echo esc_attr__('Search your article', 'textdomain'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
            <i class="fa fa-search search-box-icon"></i>
        </form>
    </div>
</div>

<!-- Categories Overlap -->
<div class="category_page_categories_overlap">
    <div class="container">
        <div class="row">
            <div class="col-lg-10">
                <div class="row justify-content-between">
                    <?php
                    $tip_category = get_term_by('slug', 'tip-category', 'tip-category');

                    if ($tip_category && !is_wp_error($tip_category)) {
                        $args = array(
                            'exclude' => $tip_category->term_id,
                        );
                        $categories = get_categories($args);
                    } else {
                        $categories = array();
                    }


                    foreach ($categories as $category) {
                        $category_image_id = get_term_meta($category->term_id, 'category_image', true);
                        $category_image_url = wp_get_attachment_image_url($category_image_id, 'thumbnail');
                    ?>

                        <div class="category_page_col">
                            <a href="<?php echo get_category_link($category->term_id); ?>">
                                <?php if ($category_image_url) { ?>
                                    <img src="<?php echo esc_url($category_image_url); ?>" alt="<?php echo esc_attr__('Category Image', 'text-domain'); ?>">
                                <?php } else { ?>
                                    <img src="https://picsum.photos/150/150">
                                <?php } ?>
                                <h5><?php echo $category->name; ?></h5>
                            </a>
                        </div>

                    <?php
                    }
                    ?>

                </div>
            </div>

            <div class="col-lg-2 d-flex align-self-center justify-content-center">
                <a href="<?php echo home_url('/tip-categories'); ?>">
                    <div class="category_page_col_more align-self-center justify-content-center">
                        <i class="fa-solid fa-right-long fa-xl mb-3"></i>
                        <h5>More</h5>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>

<!-- Tip Category Page Content -->
<div class="category-page">
    <div class="container py-5">
        <h3 style="text-align: center;color:white !important">Tips in this category</h3>
        <hr>
        <?php
        $tip_category = get_term_by('slug', 'top-tips', 'tip-category');
        $tip_category_id = $tip_category->term_id;

        $args = array(
            'post_type' => 'tips',
            'tax_query' => array(
                array(
                    'taxonomy' => 'tip-category',
                    'field' => 'term_id',
                    'terms' => $tip_category_id,
                ),
            ),
        );        

        $tip_query = new WP_Query($args);

        if ($tip_query->have_posts()) {
        ?>
            <div class="row">
                <?php
                while ($tip_query->have_posts()) {
                    $tip_query->the_post();
                ?>
                    <div class="col-lg-3 p-3">
                        <div class="category_page_article">
                            <?php
                            the_title('<h3>', '</h3>');
                            ?>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a class="btn btn-secondary" href="<?php the_permalink(); ?>">Read More</a>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        <?php
        } else {
            echo 'No tips found.';
        }
        wp_reset_postdata();
        ?>
    </div>
</div>

<?php
get_footer();
