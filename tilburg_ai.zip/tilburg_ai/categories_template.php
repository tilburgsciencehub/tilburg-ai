<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Post Categories
*/

get_header();
?>
<div class="category_page_banner">
    <h1 class="category_title mb-4" style="color:white !important;">Need an article?</h1>
    <div class="search-form-container">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" class="search-field" placeholder="<?php echo esc_attr__('Search your article', 'textdomain'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
            <i class="fa fa-search search-box-icon"></i>
        </form>
    </div>
</div>

<div class="categories-page">
    <div class="container py-5">
        <h3 style="text-align: center;color:white !important">Browse Categories</h3>
        <hr>
        <?
        $categories = get_categories();

        if ($categories) {
        ?>
            <div class="row">
                <?php
                foreach ($categories as $category) {
                ?>
                    <div class="col-lg-3 p-3">

                        <div class="category_page_article">
                            
                            <h3><?php echo $category->name; ?></h3>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a class="btn btn-secondary" href="<?php echo get_category_link($category->term_id); ?>">Go To Category</a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo 'No Categories Found.';
            }
            ?>
            </div>
    </div>
</div>
<?php
get_footer();
