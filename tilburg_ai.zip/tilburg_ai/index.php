<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Basic Page (Index)
*/

get_header(); // Include the header.php template

if (have_posts()) :
    while (have_posts()) :
        the_post();
        ?>
        <div style="background-color: white;">
        <div class="container py-3">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
        </article>
        </div>
        <hr>
        </div>
        <?php
    endwhile;
else :
    ?>
    <p>No posts found.</p>
    <?php
endif;

get_footer(); // Include the footer.php template
