<?php
/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Home
*/

get_header(); // Include the header.php template
?>

<?php
$display_type = get_option('tilburg-ai-tip-category-display');
if ($display_type === 'chatbox') {
?>

    <!-- ChatGPT Textbox -->
    <section>
        <div class="container">
            <div class="justify-content-center mb-5">
                <div class="input-group my-3">
                    <div class="position-relative">
                        <div class="dropdown position-absolute" style="left: 5px; top: 5px;">
                            <a class="btn" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="bi bi-cpu"></i>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" style="min-width: 0;">
                                <a class="dropdown-item" href="#" data-icon="bi bi-cpu"><i class="bi bi-cpu"></i></a>
                                <a class="dropdown-item" href="#" data-icon="bi bi-music-note-beamed"><i class="bi bi-music-note-beamed"></i></a>
                                <a class="dropdown-item" href="#" data-icon="bi bi-book"><i class="bi bi-book"></i></a>
                            </div>
                        </div>

                        <textarea class="form-control chatgpt-textbox" style="width:600px;padding:10px 35px 10px 50px;" rows="6" placeholder="Send a message..."></textarea>

                        <div class="text-center mt-3">
                            <button class="btn btn-primary contribute-button">Go!</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- End ChatGPT Textbox -->

<?php
} elseif ($display_type === 'header') {
?>
    <!-- Basic Header -->
    <section class="basic-header py-3">
        <div class="container">
            <h1 class="text-center" style="color:white !important;">Looking for an Article?</h1>
            <div id="search">
                <svg viewBox="0 0 420 60" xmlns="http://www.w3.org/2000/svg" class="icon-index">
                    <rect class="bar" />

                    <g class="magnifier">
                        <circle class="glass" />
                        <line class="handle" x1="32" y1="32" x2="44" y2="44"></line>
                    </g>

                    <g class="sparks">
                        <circle class="spark" />
                        <circle class="spark" />
                        <circle class="spark" />
                    </g>

                    <g class="burst pattern-one">
                        <circle class="particle circle" />
                        <path class="particle triangle" />
                        <circle class="particle circle" />
                        <path class="particle plus" />
                        <rect class="particle rect" />
                        <path class="particle triangle" />
                    </g>
                    <g class="burst pattern-two">
                        <path class="particle plus" />
                        <circle class="particle circle" />
                        <path class="particle triangle" />
                        <rect class="particle rect" />
                        <circle class="particle circle" />
                        <path class="particle plus" />
                    </g>
                    <g class="burst pattern-three">
                        <circle class="particle circle" />
                        <rect class="particle rect" />
                        <path class="particle plus" />
                        <path class="particle triangle" />
                        <rect class="particle rect" />
                        <path class="particle plus" />
                    </g>
                </svg>
                <input type="search" class="fade-in" name="s" aria-label="Search for inspiration" placeholder="Search for inspiration" onkeydown="handleSearch(event)" />

                <script>
                    function handleSearch(event) {
                        if (event.keyCode === 13) {
                            event.preventDefault();
                            var searchValue = event.target.value;
                            if (searchValue.trim() !== '') {
                                // Redirect to the search results page with the search query
                                window.location.href = '<?php echo esc_url(home_url('/')); ?>?s=' + encodeURIComponent(searchValue);
                            }
                        }
                    }
                </script>
            </div>
        </div>
    </section>
    <!-- End Basic Header -->

<?php
}
?>

<!-- Tips Cards !-->
<section>
    <div class="container">
        <div class="mt-3">

            <!--- Row 1-->
            <div class="row justify-content-between align-items-center">

                <?php
                $tip_category_id = get_option('tilburg-ai-tip-category');

                $args = array(
                    'post_type' => 'tips',
                    'posts_per_page' => 3,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'tip-category',
                            'field' => 'term_id',
                            'terms' => $tip_category_id,
                        ),
                    ),
                );

                $loop = new WP_Query($args);

                if ($loop->have_posts()) {
                    while ($loop->have_posts()) {
                        $loop->the_post();
                ?>
                        <div class="col tip-card">
                            <div class="d-flex justify-content-between">
                                <h5><?php the_title(); ?></h5>
                                <?php
                                $categories = get_the_terms(get_the_ID(), 'tip-category');
                                if ($categories && !is_wp_error($categories)) {
                                    foreach ($categories as $category) {
                                        echo '<a href="' . get_term_link($category) . '" class="tag_category">' . $category->name . '</a>';
                                    }
                                } else {
                                    echo '<span class="tag_category">No Category</span>';
                                }
                                ?>
                            </div>
                            <p class="text-secondary"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                            <div class="row">
                                <div class="col">
                                    <?php
                                    if ($display_type === 'chatbox' || !($display_type)) {?>
                                    <button class="btn btn-secondary btn-third mr-2">Try it</button>
                                    <?php }?>
                                    <a class="btn btn-secondary" href="<?php the_permalink(); ?>">Learn More</a>
                                </div>
                            </div>
                        </div>
                <?php
                    }
                    wp_reset_postdata(); // Reset post data to prevent conflicts with other queries
                } else {
                    echo 'No tips found.';
                }

                ?>
            </div>
        </div>
    </div>
</section>
<!-- End Tips Cards !-->

<!-- Article Scroll -->
<section name="infinity_scroll my-5">
    <div class="container" style="margin-top:50px;">
        <div id="my-element">
            <div class="infinity_scroll_item" id="infinity_scroll_item">
                <div class="row justify-content-between" id="infinity_scroll_item_row" class="infinity_scroll_item_row" style="margin-top: 15px;display: none;">

                    <!-- Top 6 Articles -->
                    <div class="card-large card-white">
                        <div class="bg-overlay top_articles_overlay">
                            <div class="infinity-item-overlay-content-card-white">
                                <h5>Top Articles</h5>
                                <div class="row mt-1">


                                    <?php
                                    $counter = 0;
                                    $top_category_id = get_option('tilburg-ai-top-category');

                                    $args = array(
                                        'post_type' => 'post',
                                        'posts_per_page' => 6,
                                        'tax_query' => array(
                                            array(
                                                'taxonomy' => 'category',
                                                'field' => 'term_id',
                                                'terms' => $top_category_id,
                                            ),
                                        ),
                                    );
                                    $posts_query = new WP_Query($args);

                                    if ($posts_query->have_posts()) {
                                        while ($posts_query->have_posts()) {
                                            $counter++;
                                            $posts_query->the_post();

                                            if ($counter === 1 || $counter = 4) { ?>
                                                <div class="col-lg-6">
                                                <?php }
                                                ?>

                                                <div class="row mt-3">

                                                    <div class="col-2" style="display: flex;justify-content: center;align-items: center;">
                                                        <img style="height:50;width:50px;" src="<?php if (has_post_thumbnail()) {
                                                                                                    the_post_thumbnail_url();
                                                                                                } else {
                                                                                                    echo 'https://picsum.photos/370/370';
                                                                                                } ?>">
                                                    </div>
                                                    <div class="col-10" style=" display: flex;flex-direction: column; justify-content: center; align-items: flex-start;
                                                height: 100%;">
                                                        <a href="<?php echo the_permalink(); ?>">
                                                            <h6 style="text-align: start;"><?php the_title(); ?></h6>
                                                        </a>
                                                        <span style="font-size: 15px;"><?php echo wp_trim_words(get_the_excerpt(), 7, '...'); ?></span>
                                                    </div>
                                                </div>

                                                <?php
                                                if ($counter ===  3 || $counter = 6) { ?>
                                                </div>
                                    <?php
                                                }
                                            }
                                        } else {
                                            echo 'No posts found.';
                                        }
                                        wp_reset_postdata(); // Reset the post data
                                    ?>






                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- End Top 6 Articles -->

                    <!-- Most Read Article -->
                    <?php
                    $most_read_post_id = get_option('tilburg-ai-most-read-post');
                    $post_title = '';
                    $post_excerpt = '';
                    $post_thumbnail_url = 'https://picsum.photos/370/370';

                    if ($most_read_post_id) {
                        $post = get_post($most_read_post_id);
                        if ($post) {
                            $post_title = $post->post_title;
                            $post_excerpt = get_the_excerpt($post);
                            $post_thumbnail_url = has_post_thumbnail($post) ? get_the_post_thumbnail_url($post) : 'https://picsum.photos/370/370';
                        }
                    }
                    ?>

                    <div class="card-square" style="background-image: url(<?php echo $post_thumbnail_url; ?>);">
                        <span class="tag_most_viewed"><i class="fa-solid fa-eye mr-1"></i> Most Read This Week</span>
                        <div class="bg-overlay">
                            <div class="infinity-item-overlay-content">
                                <a href="<?php echo get_permalink($post->ID); ?>">
                                    <div class="row">
                                        <h4><?php echo $post_title; ?></h4>
                                    </div>
                                    <div class="row">
                                        <p class="infinity-item-overlay-text"><?php echo $post_excerpt; ?></p>
                                    </div>
                                </a>
                                <div class="row infinity-item-icon-row">
                                    <div class="col p-0">
                                        <?php
                                        $categories = get_the_category($post->ID);
                                        if ($categories) {
                                            foreach ($categories as $category) {
                                                echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><span class="tag_infinity_category">' . $category->name . '</span></a>';
                                            }
                                        } else {
                                            echo '<span class="tag_infinity_category">No Category</span>';
                                        }
                                        ?>
                                    </div>
                                    <div class="col p-0">
                                        <?php if (get_option('tilburg-ai-enable-favourites') === 'true') { ?>
                                            <i class="fa-solid fa-star fa-lg infinity-item-icon"></i>
                                        <?php } ?>
                                        <?php if (get_option('tilburg-ai-enable-likes') === 'true') { ?>
                                            <i class="fa-solid fa-thumbs-up fa-lg infinity-item-icon"></i>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Most Read Article -->

                </div>
            </div>

            <!-- Articles -->
            <?php

            $top_articles_category = get_category_by_slug('top-articles');

            $most_read_post_id = get_option('tilburg-ai-most-read-post');

            $args = array(
                'post_type' => 'post',
                'posts_per_page' => -1,
                'category__not_in' => array($top_articles_category->term_id),
                'post__not_in' => array($most_read_post_id),
            );

            $query = new WP_Query($args);


            if ($query->have_posts()) {
                $counter = 0;
                while ($query->have_posts()) {
                    $query->the_post();

                    # Increase counter with 1
                    $counter++;

                    # Open Row for every 10 blogs
                    if ($counter === 1) { ?>
                        <div class="row justify-content-between mb-3" id="infinity_scroll_item_row" style="display:none">
                        <?php }

                    # Create Small Card For Position <= 6, = 8 or = 9
                    if ($counter <= 6 || $counter === 8 || $counter === 9) {
                        ?>
                            <div class="card-square" style="background-image: url(<?php if (has_post_thumbnail()) {
                                                                                        the_post_thumbnail_url();
                                                                                    } else {
                                                                                        echo 'https://picsum.photos/370/370';
                                                                                    } ?>);">
                                <article>
                                    <div class="bg-overlay">
                                        <div class="infinity-item-overlay-content">
                                            <a href="<?php echo the_permalink(); ?>">
                                                <div class="row">
                                                    <h4><?php the_title(); ?></h4>
                                                </div>
                                                <div class="row">
                                                    <p class="infinity-item-overlay-text"><?php echo wp_trim_words(get_the_excerpt(), 10, '...'); ?></p>
                                                </div>
                                            </a>

                                            <div class="row infinity-item-icon-row">
                                                <div class="col p-0">
                                                    <?php
                                                    $categories = get_the_category();
                                                    if ($categories) {
                                                        foreach ($categories as $category) {
                                                            echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><span class="tag_infinity_category">' . $category->name . '</span></a>';
                                                        }
                                                    } else {
                                                        echo '<span class="tag_infinity_category">No Category</span>';
                                                    }
                                                    ?>
                                                </div>
                                                <div class="col p-0">
                                                    <?php if (get_option('tilburg-ai-enable-favourites') === 'true') { ?>
                                                        <i class="fa-solid fa-star fa-lg infinity-item-icon"></i>
                                                    <?php } ?>
                                                    <?php if (get_option('tilburg-ai-enable-likes') === 'true') { ?>
                                                        <i class="fa-solid fa-thumbs-up fa-lg infinity-item-icon"></i>
                                                    <?php } ?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </article>
                            </div>
                        <?php
                    }

                    # Create Large card for position 7 and 10
                    elseif ($counter === 7 || $counter === 10) {
                        ?>
                            <div class="card-large" style="background-image: <?php if (has_post_thumbnail()) {
                                                                                    the_post_thumbnail('thumbnail');
                                                                                } else { ?>url('https://picsum.photos/760/370');<?php } ?>">
                                <div class="bg-overlay">
                                    <div class="infinity-item-overlay-content" style="max-width: 80%;">
                                        <div class="row">
                                            <h4><?php the_title(); ?></h4>
                                        </div>
                                        <div class="row">
                                            <p class="infinity-item-overlay-text"><?php echo wp_trim_words(get_the_excerpt(), 40, '...'); ?></p>
                                        </div>
                                        <div class="row infinity-item-icon-row">
                                            <?php
                                            $categories = get_the_category();
                                            if ($categories) {
                                                foreach ($categories as $category) {
                                                    echo '<a href="' . esc_url(get_category_link($category->term_id)) . '">';
                                                    echo '<span class="tag_infinity_category">' . $category->name . '</span>';
                                                    echo '</a>';
                                                }
                                            } else {
                                                echo '<span class="tag_infinity_category">No Category</span>';
                                            }
                                            ?>
                                        </div>
                                        <div class="row infinity-item-icon-row">
                                            <?php if (get_option('tilburg-ai-enable-favourites') === 'true') { ?>
                                                <i class="fa-solid fa-star fa-lg infinity-item-icon"></i>
                                            <?php } ?>
                                            <?php if (get_option('tilburg-ai-enable-likes') === 'true') { ?>
                                                <i class="fa-solid fa-thumbs-up fa-lg infinity-item-icon"></i>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                    }

                    #make new row after card 3, 6 and 8
                    if ($counter === 3 || $counter === 6 || $counter === 8) {
                        ?>
                        </div>
                        <div class="row justify-content-between mb-3" id="infinity_scroll_item_row" style="display:none;">
                        <?php
                    }

                    # Close section for every 10 blogs
                    if ($counter === 10) {
                        $counter = 0
                        ?>
                        </div>
            <?php }
                }
                wp_reset_postdata();
            } else {
                echo 'No posts found.';
            }

            if ($counter % 10 !== 0) {
                echo '</div>';
            }
            ?>
            <!-- End Articles -->

        </div>
    </div>
</section>
<br><br>

<!-- Script for Slider -->
<script type="module">
    import Swiper from 'https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.esm.browser.min.js'
    const swiper = new Swiper('.swiper', {
        // Optional parameters
        direction: 'horizontal',
        loop: true,

        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },

        slidesPerView: 5,
        spaceBetween: 20,

        breakpoints: {
            // when window width is >= 320px
            320: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            // when window width is >= 480px
            480: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            // when window width is >= 640px
            640: {
                slidesPerView: 5,
                spaceBetween: 32
            }
        }
    });
</script>

<!-- Script for Infinity Scroll -->
<script>
    var windowHeight = window.innerHeight;

    var myElement = document.getElementById('my-element');

    var nestedDivs = myElement.querySelectorAll('#infinity_scroll_item_row');

    nestedDivs[0].style.display = 'flex'

    jQuery(window).scroll(function() {
        for (var i = 0; i < nestedDivs.length; i++) {

            if (nestedDivs[i].style.display === 'flex' && nestedDivs[i].getBoundingClientRect().top < windowHeight) {
                var nextDiv = i + 1
                nestedDivs[nextDiv].style.display = 'flex'
            } else {
                console.log('Element is not within the visible portion of the window');
            }
        }
    })
</script>
<!-- End of scripts -->

<?php
get_footer(); // Include the footer.php template
?>