<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Header
*/

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'head.php'; ?>
    <?php wp_head(); ?>
    <style>
        body {
            background-size: cover;
            background-image: linear-gradient(#01336560, #01336569), url('<?
                                    $background_id = get_option('tilburg-ai-body-background');
                                    if (!empty($background_id)) {
                                        $background_url = $background_id ? wp_get_attachment_url($background_id) : false;
                                        echo $background_url;
                                    } else {
                                        echo 'https://images.unsplash.com/photo-1597224808634-55ea5b988d01?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2751&q=80';
                                    }
                                    ?>');
        }
    </style>
</head>

<?php
$logo_id = get_option('tilburg-ai-logo');
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : false;
?>

<body <?php body_class(); ?>>
    <header>
        <!-- Nav Bar -->
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>" style="color:white;">
                <?php if ($logo_url) : ?>
                    <img src="<?php echo esc_url($logo_url); ?>" class="logo_header" alt="Logo" />
                <?php else : ?>
                    <?php bloginfo('name'); ?>
                <?php endif; ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <?php
                    $header_menu = get_option('tilburg-ai-header-menu');
                    $menu_items = wp_get_nav_menu_items($header_menu);

                    if ($menu_items) {
                        foreach ($menu_items as $menu_item) {
                            echo '<li class="nav-item nav-link-margin"><a class="nav-link" href="' . $menu_item->url . '">' . $menu_item->title . '</a></li>';
                        }
                    }
                    ?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php if (is_user_logged_in()) : ?>
                        <li class="nav-item nav-link-margin">
                            <a class="nav-link" href="my-account">
                                <i class="fa fa-user nav-link-margin"></i> My Account
                            </a>
                        </li>
                    <?php else : ?>
                        <li class="nav-item nav-link-margin">
                            <a class="nav-link" href="<?php echo esc_url(wp_login_url()); ?>">
                                <i class="fa fa-user nav-link-margin"></i> Sign In
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>

    </header>
    <div class="content-wrapper">