<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Tip Categories
*/

get_header();
?>
<div class="category_page_banner">
    <h1 class="category_title mb-4" style="color:white !important;">Need a tip?</h1>
    <div class="search-form-container">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" class="search-field" placeholder="<?php echo esc_attr__('Search for tips', 'textdomain'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
            <i class="fa fa-search search-box-icon"></i>
        </form>
    </div>
</div>

<div class="categories-page">
    <div class="container py-5">
        <h3 style="text-align: center; color: white !important;">Browse Tip Categories</h3>
        <hr>
        <?php
        $tip_categories = get_terms('tip-category');

        if ($tip_categories && !is_wp_error($tip_categories)) {
        ?>
            <div class="row">
                <?php
                foreach ($tip_categories as $tip_category) {
                    $category_link = get_term_link($tip_category);
                    ?>
                    <div class="col-lg-3 p-3">
                        <div class="category_page_article">
                            <h3><?php echo $tip_category->name; ?></h3>
                            <p><?php echo wp_trim_words($tip_category->description, 15, '...'); ?></p>
                            <a class="btn btn-secondary" href="<?php echo esc_url($category_link); ?>">Go To Category</a>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        <?php
        } else {
            echo 'No Tip Categories Found.';
        }
        ?>
    </div>
</div>
<?php
get_footer();
?>