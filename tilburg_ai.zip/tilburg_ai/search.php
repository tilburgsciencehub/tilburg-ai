<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Search Results
*/

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <header class="page-header">
                <h5 class="py-3" style="text-align: center;color:white !important;">Showing search results for:</h5>
                <h3 class="page-title" style="text-align: center;color:white !important;">'<?php printf(esc_html__(get_search_query())); ?>'</h3>
            </header>

            <div class="search-results my-3" style="padding: 15px;">
                <?php if (have_posts()) : ?>
                    <?php while (have_posts()) : the_post(); ?>
                        <?php if ('post' === get_post_type()) : ?>
                            <div class="" style="color:#7ea7ce"><i class="fa-regular fa-newspaper" style="margin-top: 4px;margin-right:5px;"></i> Article</div>
                        <?php elseif ('tips' === get_post_type()) : ?>
                            <div class="" style="color:#7ea7ce"><i class="fa-solid fa-circle-info" style="margin-top: 4px;margin-right:5px;"></i> Tip</div>
                            <?php elseif ('page' === get_post_type()) : ?>
                            <div class="" style="color:#7ea7ce"><i class="fa-solid fa-file" style="margin-top: 4px;margin-right:5px;"></i> Page</div>
                        <?php endif; ?>
                        <a href="<?php the_permalink(); ?>">

                            <h3 style="margin-bottom:-3px;"><?php the_title(); ?></h3>
                        </a>
                        <div style=""><?php the_excerpt(); ?></div>
                        <hr>
                    <?php endwhile;
                else : ?>
                    <p><?php esc_html_e('No results found.', 'text-domain'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<?php
get_footer();
?>