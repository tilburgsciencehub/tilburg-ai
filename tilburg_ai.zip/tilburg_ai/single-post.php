<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Single Post
*/

get_header();

while (have_posts()) {
    the_post();

    // Display the tip content here
?>
    <!-- Tips Cards !-->
    <div class="container my-5">
        <div class="row">
            <div class="col col-lg-4">
                <div class="sidebar_one">
                    <h3 style="font-weight: 500;">More in this category</h3>
                    <hr class="divider">

                    <?php
                    // Get the current blogss category
                    $categories = get_the_terms(get_the_ID(), 'category');
                    if ($categories && !is_wp_error($categories)) {
                        $category_slugs = wp_list_pluck($categories, 'slug');

                        // Display a list of tip titles within the same categories, excluding the current post
                        $args = array(
                            'post_type' => 'post',
                            'posts_per_page' => -1, // Retrieve all posts from the categories
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'category',
                                    'field' => 'slug',
                                    'terms' => $category_slugs,
                                    'operator' => 'IN', // Include posts from any of the categories
                                ),
                            ),
                            'post__not_in' => array(get_the_ID()), // Exclude the current post
                        );

                        $related_posts = new WP_Query($args);

                        if ($related_posts->have_posts()) {
                            echo '<ul class="sidebar_article_menu">';
                            while ($related_posts->have_posts()) {
                                $related_posts->the_post();
                                echo '<li style="margin-top: 5px;">';
                                echo '<h6><a href="' . get_permalink() . '">' . get_the_title() . '</a></h6>';
                                echo '</li>';
                            }
                            echo '</ul>';
                            wp_reset_postdata();
                        }
                    }

                    ?>

                </div>
                <div class="sidebar_two">
                    <div class="related-articles-container row" style="height: fit-content;margin-left: 5px;">
                        <h4 style="font-weight: 500;margin-top: 10px;">Other Categories</h4>
                        <i class="fa-solid fa-link ml-2" style="color:#013365 !important;"></i>
                    </div>

                    <?php
                    // Get the current post's categories
                    $categories = get_the_terms(get_the_ID(), 'category');
                    if ($categories && !is_wp_error($categories)) {
                        $current_category_ids = wp_list_pluck($categories, 'term_id');

                        // Get all categories excluding the ones the current post belongs to
                        $args = array(
                            'taxonomy' => 'category',
                            'exclude' => $current_category_ids,
                        );
                        $categories = get_categories($args);

                        if ($categories) {
                            echo '<ul class="sidebar_related_menu">';
                            foreach ($categories as $category) {
                                echo '<li style="margin-top: 5px;">';
                                echo $category->name;
                                echo '</li>';
                            }
                            echo '</ul>';
                        } else {
                            echo '<ul class="sidebar_related_menu">';
                            echo '<li style="margin-top: 5px;">';
                            echo 'No other categories available';
                            echo '</li>';
                            echo '</ul>';
                        }
                    }
                    ?>
                </div>
            </div>
            <div class="col col-lg-8 main_article">
                <ul class="icon-list">
                    <li><button class="btn btn-primary contribute-button">Share</button></li>
                    <li><i onclick="addPostToFavorites(<?php echo get_the_ID(); ?>); return false;" class="fa-solid fa-heart fa-xl"></i></li>
                    <li><i class="fa-brands fa-facebook fa-xl"></i></li>
                    <li><i class="fa-brands fa-instagram fa-xl"></i></li>
                    <li><i class="fa-brands fa-linkedin fa-xl"></i></li>
                    <li><i class="fa-brands fa-twitter fa-xl"></i></li>
                </ul>
                <script>
                    function addPostToFavorites(postId) {

                        $.ajax({
                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
                            type: 'POST',
                            data: {
                                action: 'add_to_favorites_posts',
                                post_id: postId
                            },
                            success: function(response) {
                                // Handle the response
                                if (response.success) {
                                    console.log(response.data.message);
                                    // Get the element with the class 'fa-solid fa-heart fa-xl'
                                    var heartIcon = document.querySelector('.fa-solid.fa-heart.fa-xl');

                                    if (response.data.message === 'added') {
                                        heartIcon.style.color = 'red';
                                    } else {
                                        heartIcon.style.color = '#013365';
                                    }

                                } else {
                                    console.log('An error occurred. Please try again.');
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                console.log('AJAX error: ' + textStatus + ' - ' + errorThrown);
                            }
                        });
                    }
                </script>

                <hr class="divider">



                <h1 class="mt-4"><?php the_title(); ?></h1>
                <div>
                    <?php
                    // Retrieve and process the content with shortcodes
                    $content_with_shortcodes = do_shortcode(get_the_content());

                    // Output the processed content
                    echo $content_with_shortcodes;

                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Container -->

<?php
}

get_footer();
