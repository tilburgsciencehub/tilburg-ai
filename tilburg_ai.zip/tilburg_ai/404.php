<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: 404
*/

$logo_id = get_option('tilburg-ai-logo');
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : false;
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'head.php'; ?>
    <?php wp_head(); ?>
    <style>
        body {
            background-image: url('http://tilburgai.local/wp-content/uploads/2023/05/Background.png');
        }
    </style>
</head>

<body>
    <div class="container align-items-center p-5" style="">
        <div style="margin-top:20%;background-color:#013365;border-radius:10px;" class="p-5">
            <div class="row d-flex justify-content-center align-items-center">
                <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>" style="color:white;">
                    <?php if ($logo_url) : ?>
                        <img src="<?php echo esc_url($logo_url); ?>" class="logo_header" alt="Logo" />
                    <?php else : ?>
                        <?php bloginfo('name'); ?>
                    <?php endif; ?>
                </a>
            </div>
            <div class="row d-flex justify-content-center align-items-center">
                <h3 style="color: white !important;">Something went wrong. This page is not available. </h3>
            </div>
        </div>
    </div>
</body>