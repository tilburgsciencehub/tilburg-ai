<?php

// Logo Section Text
function tilburg_ai_footer_section_callback()
{
    echo '<p>Choose the settings for the Footer.</p>';
}

// Logo Sanitize Function
function tilburg_ai_footer_logo_sanitize_image_upload($input)
{
    if (isset($_FILES['tilburg-ai-footer-logo'])) {

        $file = $_FILES['tilburg-ai-footer-logo'];

        // Handle the file upload
        $overrides = array('test_form' => false);
        $logo = wp_handle_upload($file, $overrides);

        if ($logo && !isset($logo['error'])) {
            $upload_dir = wp_upload_dir();
            $logo_path = $upload_dir['url'] . '/' . basename($logo['file']);

            // Save the attachment ID
            $attachment_id = wp_insert_attachment(array(
                'post_mime_type' => $logo['type'],
                'post_title' => sanitize_file_name($logo['file']),
                'post_content' => '',
                'post_status' => 'inherit'
            ), $logo['file']);

            update_option('tilburg-ai-footer-logo', $attachment_id);

            return $attachment_id;
        }
    }

    return $input;
}

// Upload Logo Function
function tilburg_ai_footer_logo_callback()
{
    $logo = get_option('tilburg-ai-footer-logo');
    $image_url = wp_get_attachment_url($logo);
    ?>
        <div>
            <input type="hidden" name="tilburg-ai-footer-logo" id="tilburg-ai-footer-logo" value="<?php echo esc_attr($logo); ?>" />
            <img id="footer_logo" src="<?php echo esc_attr($image_url); ?>" alt="Logo" width="150" />
        </div>
        <div>
            <button type="button" id="tilburg-ai-footer-upload-logo" class="button">Choose Image</button>
            <button type="button" id="tilburg-ai-footer-remove-logo" class="button">Remove Image</button>
        </div>
        <script>
            jQuery(document).ready(function($) {
                // Upload logo button click
                $('#tilburg-ai-footer-upload-logo').click(function(e) {
                    e.preventDefault();

                    // Create the media frame
                    var frame = wp.media({
                        title: 'Select Logo',
                        button: {
                            text: 'Select'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                    // Handle selected image
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        $('#tilburg-ai-footer-logo').val(attachment.id);
                        $('#footer_logo').attr('src', attachment.url);
                    });

                    // Open the media frame
                    frame.open();
                });

                // Remove logo button click
                $('#tilburg-ai-footer-remove-logo').click(function(e) {
                    e.preventDefault();
                    $('#tilburg-ai-footer-logo').val('');
                    $('img').attr('src', '');
                });
            });
        </script>
    <?php
}

// Footer Background Color
function tilburg_ai_footer_background_callback()
{
    $background_color = get_option('tilburg-ai-footer-background-color');
    ?>
        <input type="text" name="tilburg-ai-footer-background-color" value="<?php echo esc_attr($background_color); ?>">
        <p>Fill in the color code or color name (e.g. white)</p>
    <?php
}

// Footer Text Color
function tilburg_ai_footer_text_color_callback()
{
    $text_color = get_option('tilburg-ai-footer-text-color');
    ?>
        <input type="text" name="tilburg-ai-footer-text-color" value="<?php echo esc_attr($text_color); ?>">
        <p>Fill in the color code or color name (e.g. white)</p>
    <?php
}

// Footer Menu Callback
function tilburg_ai_footer_menu_callback()
{
    $footer_menu = get_option('tilburg-ai-footer-menu');
    $menus = get_terms('nav_menu');

    echo '<select name="tilburg-ai-footer-menu">';
    foreach ($menus as $menu) {
        $selected = selected($footer_menu, $menu->term_id, false); // Compare against the saved footer menu value
        echo '<option value="' . esc_attr($menu->term_id) . '" ' . $selected . '>' . esc_html($menu->name) . '</option>';
    }
    echo '</select>';
}

// Footer Text
function tilburg_ai_footer_text_callback() {
    $footer_text = get_option('tilburg-ai-footer-text');
    ?>
    <textarea name="tilburg-ai-footer-text" rows="5" cols="50"><?php echo esc_textarea($footer_text); ?></textarea>
    <p>Fill in the footer text.</p>
    <?php
}

?>