<?php

// Callback function for the header section
function tilburg_ai_header_section_callback()
{
    echo '<p>Select the menu to be displayed in the header.</p>';
}

// Callback function for the header menu field
function tilburg_ai_header_menu_callback()
{
    $header_menu = get_option('tilburg-ai-header-menu');
    $menus = get_terms('nav_menu');

    echo '<select name="tilburg-ai-header-menu">';
    foreach ($menus as $menu) {
        $selected = selected($header_menu, $menu->term_id, false); // Compare against the saved header menu value
        echo '<option value="' . esc_attr($menu->term_id) . '" ' . $selected . '>' . esc_html($menu->name) . '</option>';
    }
    echo '</select>';
}

// Callback function for the logo section
function tilburg_ai_logo_section_callback()
{
    echo '<p>Upload your logo image.</p>';
}

// Callback function for the logo field
function tilburg_ai_logo_callback()
{
    $logo = get_option('tilburg-ai-logo');
    $image_url = wp_get_attachment_url($logo);
    ?>
        <div>
            <input type="hidden" name="tilburg-ai-logo" id="tilburg-ai-logo" value="<?php echo esc_attr($logo); ?>" />
            <img src="<?php echo esc_attr($image_url); ?>" alt="Logo" width="150" />
        </div>
        <div>
            <button type="button" id="tilburg-ai-upload-logo" class="button">Choose Image</button>
            <button type="button" id="tilburg-ai-remove-logo" class="button">Remove Image</button>
        </div>
        <script>
            jQuery(document).ready(function($) {
                // Upload logo button click
                $('#tilburg-ai-upload-logo').click(function(e) {
                    e.preventDefault();

                    // Create the media frame
                    var frame = wp.media({
                        title: 'Select Logo',
                        button: {
                            text: 'Select'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                    // Handle selected image
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        $('#tilburg-ai-logo').val(attachment.id);
                        $('img').attr('src', attachment.url);
                    });

                    // Open the media frame
                    frame.open();
                });

                // Remove logo button click
                $('#tilburg-ai-remove-logo').click(function(e) {
                    e.preventDefault();
                    $('#tilburg-ai-logo').val('');
                    $('img').attr('src', '');
                });
            });
        </script>
    <?php
}

// Sanitize the image upload
function tilburg_ai_sanitize_image_upload($input)
{
    if (isset($_FILES['tilburg-ai-logo'])) {

        $file = $_FILES['tilburg-ai-logo'];

        // Handle the file upload
        $overrides = array('test_form' => false);
        $logo = wp_handle_upload($file, $overrides);

        if ($logo && !isset($logo['error'])) {
            $upload_dir = wp_upload_dir();
            $logo_path = $upload_dir['url'] . '/' . basename($logo['file']);

            // Save the attachment ID
            $attachment_id = wp_insert_attachment(array(
                'post_mime_type' => $logo['type'],
                'post_title' => sanitize_file_name($logo['file']),
                'post_content' => '',
                'post_status' => 'inherit'
            ), $logo['file']);

            update_option('tilburg-ai-logo', $attachment_id);

            return $attachment_id;
        }
    }

    return $input;
}

?>