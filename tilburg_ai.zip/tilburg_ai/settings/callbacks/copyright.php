<?php

// Copyright Section Text
function tilburg_ai_footer_copyright_section_callback()
{
    echo '<p>Choose the settings for the Copyright Section.</p>';
}

// Copyright Sectio Background Color
function tilburg_ai_footer_copyright_background_callback()
{
    $background_color = get_option('tilburg-ai-footer-copyright-background-color');
    ?>
        <input type="text" name="tilburg-ai-footer-copyright-background-color" value="<?php echo esc_attr($background_color); ?>">
        <p>Fill in the color code or color name (e.g. white)</p>
    <?php
}

// Copyright Text Color
function tilburg_ai_footer_copyright_text_color_callback()
{
    $text_color = get_option('tilburg-ai-footer-copyright-text-color');
    ?>
        <input type="text" name="tilburg-ai-footer-copyright-text-color" value="<?php echo esc_attr($text_color); ?>">
        <p>Fill in the color code or color name (e.g. white)</p>
    <?php
}

// Copyright Menu
function tilburg_ai_footer_copyright_menu_callback()
{
    $copyright_menu = get_option('tilburg-ai-footer-copyright-menu');
    $menus = get_terms('nav_menu');

    echo '<select name="tilburg-ai-footer-copyright-menu">';
    foreach ($menus as $menu) {
        $selected = selected($copyright_menu, $menu->term_id, false); // Compare against the saved footer menu value
        echo '<option value="' . esc_attr($menu->term_id) . '" ' . $selected . '>' . esc_html($menu->name) . '</option>';
    }
    echo '</select>';
}

// Copyright Text
function tilburg_ai_footer_copyright_text_callback(){
    $copyright_text = get_option('tilburg-ai-footer-copyright-text');
    ?>
        <input type="text" name="tilburg-ai-footer-copyright-text" value="<?php echo esc_attr($copyright_text); ?>">
        <p>Fill in the copyright text.</p>
    <?php
}

?>