<?php

// Body Section Callback
function tilburg_ai_body_section_callback()
{
    echo '<p>Select your Body & Homepage Settings</p>';
}

// Choose the Tip Category to Display on Homepage
function tilburg_ai_tip_category_callback()
{
    $tip_category = get_option('tilburg-ai-tip-category');
    
    $categories = get_terms(array(
        'taxonomy' => 'tip-category',
        'hide_empty' => false,
    ));

    echo '<select name="tilburg-ai-tip-category">';
    foreach ($categories as $category) {
        $selected = ($tip_category == $category->term_id) ? 'selected' : '';
        echo '<option value="' . esc_attr($category->term_id) . '" ' . $selected . '>' . esc_html($category->name) . '</option>';
    }
    echo '</select>';
}

// Choose Homepage Banner Type (Chatbox or Basic Header)
function tilburg_ai_banner_display_type_callback()
{
    $display_type = get_option('tilburg-ai-tip-category-display');
    $display_types = array(
        'chatbox' => 'ChatGPT Chatbox',
        'header' => 'Basic Header',
    );

    echo '<select name="tilburg-ai-tip-category-display">';
    foreach ($display_types as $value => $label) {
        $selected = ($display_type === $value) ? 'selected' : '';
        echo '<option value="' . esc_attr($value) . '" ' . $selected . '>' . esc_html($label) . '</option>';
    }
    echo '</select>';
}

// Choose Top Articles Category
function tilburg_ai_top_category_callback()
{
    $top_category = get_option('tilburg-ai-top-category');
    $categories = get_terms(array(
        'taxonomy' => 'category',
        'hide_empty' => false,
    ));

    // Check if the option 'tilburg-ai-top-category' is empty and update if it is
    if (empty($top_category)) {
        $top_category = get_category_by_slug('top-articles')->term_id;
        update_option('tilburg-ai-top-category', $top_category);
    }

    echo '<select name="tilburg-ai-top-category">';
    foreach ($categories as $category) {
        $selected = ($top_category == $category->term_id) ? 'selected' : '';
        echo '<option value="' . esc_attr($category->term_id) . '" ' . $selected . '>' . esc_html($category->name) . '</option>';
    }
    echo '</select>';
}

// Body Background Sanitize Image
function tilburg_ai_body_background_sanitize_image_upload($input)
{
    if (isset($_FILES['tilburg-ai-body-background'])) {

        $file = $_FILES['tilburg-ai-body-background'];

        // Handle the file upload
        $overrides = array('test_form' => false);
        $logo = wp_handle_upload($file, $overrides);

        if ($logo && !isset($logo['error'])) {
            $upload_dir = wp_upload_dir();
            $logo_path = $upload_dir['url'] . '/' . basename($logo['file']);

            // Save the attachment ID
            $attachment_id = wp_insert_attachment(array(
                'post_mime_type' => $logo['type'],
                'post_title' => sanitize_file_name($logo['file']),
                'post_content' => '',
                'post_status' => 'inherit'
            ), $logo['file']);

            update_option('tilburg-ai-body-background', $attachment_id);

            return $attachment_id;
        }
    }

    return $input;
}

// Choose Body Background Image
function tilburg_ai_body_background_callback()
{
    $logo = get_option('tilburg-ai-body-background');
    $image_url = wp_get_attachment_url($logo);
    ?>
        <div>
            <input type="hidden" name="tilburg-ai-body-background" id="tilburg-ai-body-background" value="<?php echo esc_attr($logo); ?>" />
            <img id="body_background" src="<?php echo esc_attr($image_url); ?>" alt="Logo" width="150" />
        </div>
        <div>
            <button type="button" id="tilburg-ai-body-background-upload" class="button">Choose Image</button>
            <button type="button" id="tilburg-ai-body-background-remove" class="button">Remove Image</button>
        </div>
        <script>
            jQuery(document).ready(function($) {
                // Upload logo button click
                $('#tilburg-ai-body-background-upload').click(function(e) {
                    e.preventDefault();

                    // Create the media frame
                    var frame = wp.media({
                        title: 'Select Body Background',
                        button: {
                            text: 'Select'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                    // Handle selected image
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        $('#tilburg-ai-body-background').val(attachment.id);
                        $('#body_background').attr('src', attachment.url);
                    });

                    // Open the media frame
                    frame.open();
                });

                // Remove logo button click
                $('#tilburg-ai-body-background-remove').click(function(e) {
                    e.preventDefault();
                    $('#tilburg-ai-body-background').val('');
                    $('img').attr('src', '');
                });
            });
        </script>
    <?php
}

// Enable Likes Callback 
function tilburg_ai_enable_likes_callback() {
    $enable_likes = get_option('tilburg-ai-enable-likes', 'false');
    ?>
    <select name="tilburg-ai-enable-likes">
        <option value="true" <?php selected($enable_likes, 'true'); ?>>True</option>
        <option value="false" <?php selected($enable_likes, 'false'); ?>>False</option>
    </select>
    <?php
}

// Enable Favourites Callback 
function tilburg_ai_enable_favourites_callback() {
    $enable_favourites = get_option('tilburg-ai-enable-favourites', 'false');
    ?>
    <select name="tilburg-ai-enable-favourites">
        <option value="true" <?php selected($enable_favourites, 'true'); ?>>True</option>
        <option value="false" <?php selected($enable_favourites, 'false'); ?>>False</option>
    </select>
    <?php
}

function tilburg_ai_most_read_post_new_callback() {
    $most_read_post_id = get_option('tilburg-ai-most-read-post');

    // Retrieve a list of posts to populate the select options
    $posts = get_posts(array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ));

    // Output the select field
    ?>
    <select name="tilburg-ai-most-read-post" id="tilburg-ai-most-read-post">
        <?php foreach ($posts as $post) : ?>
            <option value="<?php echo $post->ID; ?>" <?php selected($most_read_post_id, $post->ID); ?>><?php echo $post->post_title; ?></option>
        <?php endforeach; ?>
    </select>
    <?php
}

?>