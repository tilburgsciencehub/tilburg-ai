<?php

// Social Settings Text
function tilburg_ai_social_settings_section()
{
    echo '<p>Configure your social media settings:</p>';
}

// Email
function tilburg_ai_email_callback()
{
    $email = get_option('tilburg-ai-email');
    echo '<input type="text" name="tilburg-ai-email" value="' . esc_attr($email) . '">';
}

// Facebook 
function tilburg_ai_facebook_callback()
{
    $facebook = get_option('tilburg-ai-facebook');
    echo '<input type="text" name="tilburg-ai-facebook" value="' . esc_attr($facebook) . '">';
}

// LinkedIn
function tilburg_ai_linkedin_callback()
{
    $linkedin = get_option('tilburg-ai-linkedin');
    echo '<input type="text" name="tilburg-ai-linkedin" value="' . esc_attr($linkedin) . '">';
}

// Instagram
function tilburg_ai_instagram_callback()
{
    $instagram = get_option('tilburg-ai-instagram');
    echo '<input type="text" name="tilburg-ai-instagram" value="' . esc_attr($instagram) . '">';
}

// Company Info
function tilburg_ai_company_info_callback(){
    $company_info = get_option('tilburg-ai-company-info');
    echo '<input type="text" name="tilburg-ai-company-info" value="' . esc_attr($company_info) . '">';
}
?>