<?php

// Login Section
function tilburg_ai_login_section_callback()
{
    echo '<p>Choose the settings for the Login Page.</p>';
}

// Set the background color of the Login Page
function tilburg_ai_login_callback()
{
    $login_color = get_option('tilburg-ai-login-color');
    ?>
        <input type="text" name="tilburg-ai-login-color" value="<?php echo esc_attr($login_color); ?>">
        <p>Fill in the color code or color name (e.g. white)</p>
    <?php
}

?>