<?php

/*
Theme Name: Tilburg AI
Organisation: Tilburg Science Hub
Author: Tilburg Science Hub (Thierry Lahaije)
Author URI: https://tilburgsciencehub.com
Description: Tilburg AI Custom Theme
Version: 1.0
Tags: tilburg-ai artificial intelligence
Text Domain: tilburg-ai
Page Template: Settings
*/

// Add the theme settings page
function tilburg_ai_settings_page()
{
    // Check if the form has been submitted and handle the response
    if (isset($_POST['submit'])) {
        // Handle the form submission and display the response
        $response = handle_form_submission();
        echo '<div class="notice notice-' . esc_attr($response['type']) . '"><p>' . esc_html($response['message']) . '</p></div>';
    }

    // Output the settings page HTML
?>
    <div class="wrap">
        <h1>Tilburg AI Settings</h1>

        <!-- Add the tabs HTML structure -->
        <div class="tilburg-ai-settings-tabs">
            <div class="row">
                <div class="col-lg-3" style="max-width: 30%; width: 30%;">
                    <ul class="tilburg-ai-settings-tab-links">
                        <li><a href="#header-settings">Header Settings</a></li>
                        <li><a href="#body-settings">Body Settings</a></li>
                        <li><a href="#login-settings">Login Page Settings</a></li>
                        <li><a href="#footer-settings">Footer Settings</a></li>
                        <li><a href="#copyright-settings">Copyright Section Settings</a></li>
                        <li><a href="#social-settings">Social Settings</a></li>
                    </ul>
                </div>

                <!-- Start the settings form -->
                <div class="col-lg-9">
                    <form method="post" action="options.php" enctype="multipart/form-data" class="tilburg-ai-settings-form">
                        <div class="tilburg-ai-settings-tab-content">

                            <!-- Header Settings section -->
                            <div id="header-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-header-settings');
                                ?>
                            </div>

                            <!-- Body Settings section -->
                            <div id="body-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-body-settings');
                                ?>
                            </div>

                            <!-- Login Page Settings section -->
                            <div id="login-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-login-settings');
                                ?>
                            </div>

                            <!-- Footer Settings section -->
                            <div id="footer-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-footer-settings');
                                ?>
                            </div>

                            <!-- Copyright Section Settings section -->
                            <div id="copyright-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-copyright-settings');
                                ?>
                            </div>

                            <!-- Social Settings section -->
                            <div id="social-settings" class="tilburg-ai-settings-tab-section">
                                <?php
                                settings_fields('tilburg-ai-settings');
                                do_settings_sections('tilburg-ai-social-settings');
                                ?>
                            </div>
                        </div>

                        <?php
                        submit_button('Save Settings', 'primary', 'submit', false);
                        ?>
                    </form>
                </div>
            </div>
        </div>

    <?php

    // Enqueue jQuery and custom JavaScript for tab functionality
    wp_enqueue_script('jquery');
    wp_enqueue_script('tilburg-ai-tab-script', get_template_directory_uri() . '/js/tab-script.js', array('jquery'), '1.0', true);

    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css');

    // Enqueue Bootstrap JavaScript
    wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js', array('jquery'), '4.5.0', true);
}

// Register the theme settings and options
function tilburg_ai_register_settings()
{
    // Register a settings section for header settings
    add_settings_section('tilburg-ai-header-section', 'Header Settings', 'tilburg_ai_header_section_callback', 'tilburg-ai-header-settings');

    // Register a settings field for the header menu
    add_settings_field('tilburg-ai-header-menu', 'Header Menu', 'tilburg_ai_header_menu_callback', 'tilburg-ai-header-settings', 'tilburg-ai-header-section');

    // Register a settings field for the logo
    add_settings_field('tilburg-ai-logo', 'Logo', 'tilburg_ai_logo_callback', 'tilburg-ai-header-settings', 'tilburg-ai-header-section');

    // Register a settings section for Body settings
    add_settings_section('tilburg-ai-body-section', 'Body Settings', 'tilburg_ai_body_section_callback', 'tilburg-ai-body-settings');

    // Register a settings field for the tip category
    add_settings_field('tilburg-ai-tip-category', 'Tip Category', 'tilburg_ai_tip_category_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the tip category display type
    add_settings_field('tilburg-ai-tip-category-display', 'Banner Type', 'tilburg_ai_banner_display_type_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the Top Category
    add_settings_field('tilburg-ai-top-category', 'Top Articles Category', 'tilburg_ai_top_category_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the Background image
    add_settings_field('tilburg-ai-body-background', 'Body Background Image', 'tilburg_ai_body_background_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the Background image
    add_settings_field('tilburg-ai-enable-likes', 'Enable Likes', 'tilburg_ai_enable_likes_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the Background image
    add_settings_field('tilburg-ai-enable-favourites', 'Enable Favourites', 'tilburg_ai_enable_favourites_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings field for the Background image
    add_settings_field('tilburg-ai-most-read-post', 'Most Read Post', 'tilburg_ai_most_read_post_new_callback', 'tilburg-ai-body-settings', 'tilburg-ai-body-section');

    // Register a settings section for Login settings
    add_settings_section('tilburg-ai-login-section', 'Login Page Settings', 'tilburg_ai_login_section_callback', 'tilburg-ai-login-settings');

    // Register a settings field for the Login Background Color
    add_settings_field('tilburg-ai-login-color', 'Page Background Color', 'tilburg_ai_login_callback', 'tilburg-ai-login-settings', 'tilburg-ai-login-section');

    // Register a settings section for tip category settings
    add_settings_section('tilburg-ai-footer-section', 'Footer Settings', 'tilburg_ai_footer_section_callback', 'tilburg-ai-footer-settings');

    // Register a settings field for the logo
    add_settings_field('tilburg-ai-footer-logo', 'Footer Logo', 'tilburg_ai_footer_logo_callback', 'tilburg-ai-footer-settings', 'tilburg-ai-footer-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-background-color', 'Footer Background Color', 'tilburg_ai_footer_background_callback', 'tilburg-ai-footer-settings', 'tilburg-ai-footer-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-text-color', 'Footer Text Color', 'tilburg_ai_footer_text_color_callback', 'tilburg-ai-footer-settings', 'tilburg-ai-footer-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-menu', 'Footer Useful Links Menu', 'tilburg_ai_footer_menu_callback', 'tilburg-ai-footer-settings', 'tilburg-ai-footer-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-text', 'Footer Text', 'tilburg_ai_footer_text_callback', 'tilburg-ai-footer-settings', 'tilburg-ai-footer-section');

    // Register a settings section for tip category settings
    add_settings_section('tilburg-ai-footer-copyright-section', 'Footer Settings', 'tilburg_ai_footer_copyright_section_callback', 'tilburg-ai-copyright-settings');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-copyright-text-color', 'Copyright Text Color', 'tilburg_ai_footer_copyright_text_color_callback', 'tilburg-ai-copyright-settings', 'tilburg-ai-footer-copyright-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-copyright-background-color', 'Copyright Background Color', 'tilburg_ai_footer_copyright_background_callback', 'tilburg-ai-copyright-settings', 'tilburg-ai-footer-copyright-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-copyright-menu', 'Copyright Links Menu', 'tilburg_ai_footer_copyright_menu_callback', 'tilburg-ai-copyright-settings', 'tilburg-ai-footer-copyright-section');

    // Register a settings field for the footer background color
    add_settings_field('tilburg-ai-footer-copyright-text', 'Copyright Links Menu', 'tilburg_ai_footer_copyright_text_callback', 'tilburg-ai-copyright-settings', 'tilburg-ai-footer-copyright-section');

    // Register a settings section for Social settings
    add_settings_section('tilburg-ai-social-section', 'Social Settings', 'tilburg_ai_social_settings_section', 'tilburg-ai-social-settings');
    
    // Register a settings field for Email
    add_settings_field('tilburg-ai-email', 'Email', 'tilburg_ai_email_callback', 'tilburg-ai-social-settings', 'tilburg-ai-social-section');
    
    // Register a settings field for Facebook
    add_settings_field('tilburg-ai-facebook', 'Facebook', 'tilburg_ai_facebook_callback', 'tilburg-ai-social-settings', 'tilburg-ai-social-section');
    
    // Register a settings field for LinkedIn
    add_settings_field('tilburg-ai-linkedin', 'LinkedIn', 'tilburg_ai_linkedin_callback', 'tilburg-ai-social-settings', 'tilburg-ai-social-section');
    
    // Register a settings field for Instagram
    add_settings_field('tilburg-ai-instagram', 'Instagram', 'tilburg_ai_instagram_callback', 'tilburg-ai-social-settings', 'tilburg-ai-social-section');
    
    // Register a settings field for Company Info
    add_settings_field('tilburg-ai-company-info', 'Company Info', 'tilburg_ai_company_info_callback', 'tilburg-ai-social-settings', 'tilburg-ai-social-section');

    // Register the settings
    register_setting('tilburg-ai-settings', 'tilburg-ai-header-menu', 'intval');
    register_setting('tilburg-ai-settings', 'tilburg-ai-logo', 'tilburg_ai_sanitize_image_upload');
    register_setting('tilburg-ai-settings', 'tilburg-ai-tip-category', 'intval');
    register_setting('tilburg-ai-settings', 'tilburg-ai-tip-category-display');
    register_setting('tilburg-ai-settings', 'tilburg-ai-top-category');
    register_setting('tilburg-ai-settings', 'tilburg-ai-login-color');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-logo', 'tilburg_ai_footer_logo_sanitize_image_upload');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-background-color');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-text-color');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-copyright-text-color');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-copyright-background-color');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-menu');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-copyright-menu');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-copyright-text');
    register_setting('tilburg-ai-settings', 'tilburg-ai-footer-text');
    register_setting('tilburg-ai-settings', 'tilburg-ai-email');
    register_setting('tilburg-ai-settings', 'tilburg-ai-facebook');
    register_setting('tilburg-ai-settings', 'tilburg-ai-linkedin');
    register_setting('tilburg-ai-settings', 'tilburg-ai-instagram');
    register_setting('tilburg-ai-settings', 'tilburg-ai-company-info');
    register_setting('tilburg-ai-settings', 'tilburg-ai-body-background', 'tilburg_ai_body_background_sanitize_image_upload');
    register_setting('tilburg-ai-settings', 'tilburg-ai-enable-likes');
    register_setting('tilburg-ai-settings', 'tilburg-ai-enable-favourites');
    register_setting('tilburg-ai-settings', 'tilburg-ai-most-read-post');
}

// Include the necessary callback files
require_once __DIR__ . '/callbacks/header.php';
require_once __DIR__ . '/callbacks/body.php';
require_once __DIR__ . '/callbacks/login.php';
require_once __DIR__ . '/callbacks/footer.php';
require_once __DIR__ . '/callbacks/copyright.php';
require_once __DIR__ . '/callbacks/social-settings.php';

// Add the settings page to the admin menu
function tilburg_ai_add_settings_page()
{
    add_menu_page('Tilburg AI Settings', 'Tilburg AI Settings', 'manage_options', 'tilburg-ai-settings', 'tilburg_ai_settings_page', 'dashicons-admin-generic', 30);
}
add_action('admin_menu', 'tilburg_ai_add_settings_page');

// Hook into the settings API
add_action('admin_init', 'tilburg_ai_register_settings');

?>